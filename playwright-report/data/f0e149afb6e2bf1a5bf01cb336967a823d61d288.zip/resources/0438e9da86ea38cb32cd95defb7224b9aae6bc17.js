// Runtime configuration — edit this file after deployment to change values
// without rebuilding the application.
window.__APP_CONFIG__ = {
  VITE_API_BASE_URL: "https://facelink-api.cultive8.lk",
  VITE_API_VERSION: "v1",
  VITE_API_MOCKING: "false",
};
